# NewsFlix
#### Video Demo: https://youtu.be/IIqR3yvehe4
#### Description:
    NewsFlix is a platform that provides the fresh news using the newsapi's api.
    User can easily read every current news on this platform.
    NewsFlix is created using React framework.
    NewsFlix is available in dark and light mode.
    NewsFlix is build using react javascript.
    Homepage is user friendly.

